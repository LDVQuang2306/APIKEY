// eicon.h
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#import <Metal/Metal.h>
#import <MetalKit/MetalKit.h>

extern NSString * const kImageBase64_1;
extern NSString * const kImageBase64_2;
extern NSString * const kImageBase64_3;
extern NSString * const kImageBase64_4;
extern NSString * const kImageBase64_5;
extern NSString * const kImageBase64_6;
extern NSString * const kImageBase64_7;