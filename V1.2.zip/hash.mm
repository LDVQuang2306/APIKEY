#import "apikey.h"
#import "encrypt.h"


#import <Foundation/Foundation.h>

@interface KeyClass : NSObject


@end

@implementation KeyClass

// Đặt các giá trị mã hóa cần thiết
NSString * const __contact = NSSENCRYPT("Liên hệ"); // Nội dung nút liên hệ
NSString * const __Confirm = NSSENCRYPT("Xác nhận"); // Nội dung nút xác nhận
NSString * const __Input = NSSENCRYPT("Nhập Key Ở Đây"); // Nội dung ô nhập
NSString * const __kBaseURL = NSSENCRYPT("https://quangmodmap.store"); // link giữ nguyên nếu đổi = lỗi
NSString * const __TimeZone = NSSENCRYPT("Asia/Ho_Chi_Minh"); // tùy chỉnh vùng ở đây để tránh lỗi lệch múi giờ
// Load


+ (void)load {
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{


APIkey *api = [[APIkey alloc] init];

   
        
    [api setToken:@"Token package của bạn"]; // cần thiết và là bắt buộc

    [api paid:^{
            // hàm khởi động menu ở đây
    }];

    });
}

@end

