#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>


extern NSString * const __contact;
extern NSString * const __Confirm;
extern NSString * const __Input;
extern NSString * const __TimeZone;

@interface APIkey : NSObject

- (void)paid:(void (^)(void))execute;
- (void)setToken:(NSString *)tokenn;
+ (NSString *)getCurrentKey;
+ (NSString *)getRemainingTime;

@end