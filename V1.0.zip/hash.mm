#import "Quang.h"
#import "encrypt.h"
#import <Foundation/Foundation.h>

@interface KeyClass : NSObject

@end

@implementation KeyClass

// Đặt các giá trị mã hóa cần thiết
NSString * const __kHashDefaultValue = NSSENCRYPT("Token của package của bạn"); // Token package
NSString * const __contact = NSSENCRYPT("Liên hệ"); // Nội dung nút liên hệ
NSString * const __Confirm = NSSENCRYPT("Xác nhận"); // Nội dung nút xác nhận
NSString * const __Input = NSSENCRYPT("Nhập Key Ở Đây"); // Nội dung ô nhập
NSString * const __kBaseURL = NSSENCRYPT("https://quangmodmap.store"); // link giữ nguyên nếu đổi = lỗi

// Load
+ (void)load {
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        // extraInfo = [KeyClass new];
        [LDVQuang paid:^{

           // [extraInfo initTapGes];   ví dụ cách gọi hàm menu trong paid lưu ý phải bỏ hàm gọi menu ở đây và tùy theo menu sẽ có cách gọi khác nhau

        }];
    });
}



// Chú thích cho người dùng khác: Hàm khởi tạo menu, nếu cần thêm menu thì bỏ comment và gọi hàm này
// - (void)initTapGes {
//     // Khởi tạo menu ở đây
// }

@end

/* Credit : LDVQuang telegram:@quangmodmap */